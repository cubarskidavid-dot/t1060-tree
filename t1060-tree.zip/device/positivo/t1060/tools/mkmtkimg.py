#!/usr/bin/env python3
#
# Build an MTK-wrapped Android boot image (KERNEL + ROOTFS/RECOVERY).
#
import argparse
import os
import struct
import sys

ANDROID_MAGIC = b"ANDROID!"
MTK_MAGIC = 0x58881688
MTK_HEADER_SIZE = 512
HEADER_STRUCT = "<8s10I16s512s32s1024s"


def mtk_header(payload_size, name):
    name = name.encode("ascii")[:16].ljust(16, b"\0")
    hdr = struct.pack("<II", MTK_MAGIC, payload_size) + name
    hdr += b"\0" * (40 - len(hdr))
    hdr += b"\xff" * (MTK_HEADER_SIZE - len(hdr))
    return hdr


def pad(data, page_size):
    rem = len(data) % page_size
    return data if rem == 0 else data + b"\0" * (page_size - rem)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kernel", required=True)
    ap.add_argument("--ramdisk", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--cmdline", default="")
    ap.add_argument("--base", type=lambda x: int(x, 0), default=0x10000000)
    ap.add_argument("--kernel-offset", type=lambda x: int(x, 0), default=0x00008000)
    ap.add_argument("--ramdisk-offset", type=lambda x: int(x, 0), default=0x01000000)
    ap.add_argument("--tags-offset", type=lambda x: int(x, 0), default=0x00000100)
    ap.add_argument("--second-offset", type=lambda x: int(x, 0), default=0x00f00000)
    ap.add_argument("--pagesize", type=int, default=2048)
    ap.add_argument("--recovery", action="store_true")
    ap.add_argument("--max-size", type=int, default=0)
    ap.add_argument("--id", default=None)
    args = ap.parse_args()

    with open(args.kernel, "rb") as f:
        kernel = f.read()
    with open(args.ramdisk, "rb") as f:
        ramdisk = f.read()

    kernel_size = MTK_HEADER_SIZE + len(kernel)
    ramdisk_size = MTK_HEADER_SIZE + len(ramdisk)
    name = args.name.encode("ascii")[:16].ljust(16, b"\0")
    cmdline = args.cmdline.encode("ascii")[:512].ljust(512, b"\0")
    if args.id:
        boot_id = bytes.fromhex(args.id)[:32].ljust(32, b"\0")
    else:
        boot_id = b"\0" * 32

    header = struct.pack(
        HEADER_STRUCT,
        ANDROID_MAGIC,
        kernel_size,
        args.base + args.kernel_offset,
        ramdisk_size,
        args.base + args.ramdisk_offset,
        0,
        args.base + args.second_offset,
        args.base + args.tags_offset,
        args.pagesize,
        0,
        0,
        name,
        cmdline,
        boot_id,
        b"\0" * 1024,
    )
    if len(header) > args.pagesize:
        sys.exit("boot header does not fit in page size")
    out = pad(header, args.pagesize)
    out += pad(mtk_header(len(kernel), "KERNEL") + kernel, args.pagesize)
    out += pad(mtk_header(len(ramdisk), "RECOVERY" if args.recovery else "ROOTFS") + ramdisk,
               args.pagesize)

    if args.max_size and len(out) > args.max_size:
        sys.exit("image is %d bytes, larger than %d" % (len(out), args.max_size))

    with open(args.output, "wb") as f:
        f.write(out)
    print("wrote %s (%d bytes)" % (args.output, len(out)))


if __name__ == "__main__":
    main()
