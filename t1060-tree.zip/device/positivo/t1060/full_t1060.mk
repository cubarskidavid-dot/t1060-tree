#
# Copyright (C) 2026 The CyanogenMod Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Inherit from those products. Most specific first.
$(call inherit-product, device/positivo/t1060/device_t1060.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base.mk)

# Configure as mdpi tablet.
PRODUCT_AAPT_CONFIG := normal mdpi
PRODUCT_AAPT_PREF_CONFIG := mdpi
PRODUCT_CHARACTERISTICS := tablet

# Discard inherited values and use our own instead.
PRODUCT_NAME := full_t1060
PRODUCT_DEVICE := t1060
PRODUCT_BRAND := Positivo
PRODUCT_MODEL := T1060B
PRODUCT_MANUFACTURER := Positivo
