#
# Copyright (C) 2026 The CyanogenMod Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

MKMTKIMG := $(TOPDIR)/device/positivo/t1060/tools/mkmtkimg.py

$(INSTALLED_BOOTIMAGE_TARGET): $(MKMTKIMG) $(INSTALLED_KERNEL_TARGET) $(INSTALLED_RAMDISK_TARGET)
	$(hide) $(MKMTKIMG) \
		--kernel $(INSTALLED_KERNEL_TARGET) \
		--ramdisk $(INSTALLED_RAMDISK_TARGET) \
		--output $@ \
		--name "T1060.KK1.MP5.V" \
		--cmdline "androidboot.selinux=permissive androidboot.hardware=mt6589" \
		--max-size $(BOARD_BOOTIMAGE_PARTITION_SIZE)

$(INSTALLED_RECOVERYIMAGE_TARGET): $(MKMTKIMG) $(INSTALLED_KERNEL_TARGET) $(recovery_ramdisk)
	$(hide) $(MKMTKIMG) \
		--kernel $(INSTALLED_KERNEL_TARGET) \
		--ramdisk $(recovery_ramdisk) \
		--output $@ \
		--cmdline "androidboot.selinux=permissive androidboot.hardware=mt6589" \
		--recovery \
		--max-size $(BOARD_RECOVERYIMAGE_PARTITION_SIZE)
