PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/full_t1060.mk \
    $(LOCAL_DIR)/cm_t1060.mk
